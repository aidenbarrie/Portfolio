package deck;
import java.util.Random;
import java.util.ArrayList;

public class Deck
{
    public static final int NUM_CARDS = 52;
    private Random generator;
    private ArrayList<PlayingCard> deck;

    public Deck()
    {
        this.generator = new Random();
        this.deck = new ArrayList<>(NUM_CARDS);
    }
    public Deck(int seed)
    {
        this.generator = new Random(seed);
        this.deck = new ArrayList<>(NUM_CARDS);
    }
    public void initialize()
    {
        deck.clear();
        for (Suit suit : Suit.values())
        {
            for (Rank rank : Rank.values())
            {
                deck.add(new PlayingCard(rank, suit));
            }
        }
    }
    public void shuffleDeck()
    {
        for (int i = deck.size() - 1; i >= 1; i--)
        {
            int RandIndex = generator.nextInt(i + 1);
            deck.set(i, deck.set(RandIndex, deck.get(i)));
        }
    }
    public PlayingCard getCard(int index)
    {
        if (index < 0 || index >= deck.size())
        {
            
        }
        return deck.get(index);
    }
    public String toString()
    {
        return deck.toString();
    }
}